"""Trusted stdio MCP peer. Never launched inside a model command sandbox."""
from __future__ import annotations
import json
import os
import secrets
import socket
import sys
from bridge_protocol import (SOCKET_PATH, MAX_REQUEST, MAX_RESPONSE, CONNECT_TIMEOUT,
    RESPONSE_TIMEOUT, Invalid, strict_json, validate_arguments, VERIFY_SCHEMA,
    REGISTRY_SCHEMAS, SERVICE_BY_TOOL, WRITE_TOOLS)

TOOL = {
    "name": "verify",
    "description": "Read Home Assistant entity state, configuration, Core logs or dashboards. Inspect screenshot image_paths before visual claims. save_pending saves only an authorized pending dashboard edit.",
    "inputSchema": VERIFY_SCHEMA,
}
TOOLS = [TOOL, *({"name": name,
    "description": ("Authorized registry mutation only; read current state before and verify after. UNKNOWN means no automatic retry; read back first." if name in WRITE_TOOLS else "Read one existing Home Assistant registry object."),
    "inputSchema": spec} for name, spec in REGISTRY_SCHEMAS.items())]
ERROR_STATUSES = {"UNKNOWN", "UNAVAILABLE", "PERMISSION_DENIED", "VALIDATION_ERROR", "unavailable"}


def writes_enabled():
    # Advertisement snapshot supplied by the trusted worker, never a tool argument.
    # The parent independently checks its current option for every mutation.
    return os.environ.get("HA_REGISTRY_WRITE_ENABLED") == "true"


def exchange(payload, *, mutation=False):
    capability = os.environ.get("HA_VERIFICATION_CAPABILITY", "")
    if not capability:
        return {"status": "PERMISSION_DENIED", "message": "Active turn capability unavailable"}
    try:
        raw = json.dumps({**payload, "capability": capability}, allow_nan=False).encode("utf-8") + b"\n"
        if len(raw) > MAX_REQUEST:
            raise Invalid("Request size")
    except (ValueError, TypeError, UnicodeError):
        return {"status": "VALIDATION_ERROR", "message": "Invalid bounded request"}
    submitted = False
    try:
        # One connection, one line, no loop around connect/send and no retries.
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(CONNECT_TIMEOUT)
            client.connect(SOCKET_PATH)
            client.settimeout(RESPONSE_TIMEOUT)
            submitted = True  # Partial send is conservatively UNKNOWN for writes.
            client.sendall(raw)
            with client.makefile("rb") as response:
                reply = response.readline(MAX_RESPONSE + 1)
            if not reply.endswith(b"\n") or len(reply) > MAX_RESPONSE:
                raise Invalid("Invalid response framing")
            result = strict_json(reply)
            if not isinstance(result, dict) or not isinstance(result.get("status"), str):
                raise Invalid("Invalid response shape")
            if payload.get("operation") == "ha.call_service":
                statuses = {"SUCCESS", "NO_CHANGE", "ALREADY_EXISTS", "NOT_FOUND", "WRITE_FAILED", "VERIFY_FAILED", *ERROR_STATUSES}
                if result["status"] not in statuses:
                    raise Invalid("Unexpected registry status")
                if result["status"] not in ERROR_STATUSES and result.get("request_id") != payload["request_id"]:
                    raise Invalid("Mismatched request")
            return result
    except (OSError, ValueError, TypeError, UnicodeError, RecursionError):
        status = "UNKNOWN" if mutation and submitted else "UNAVAILABLE"
        message = "Outcome unknown; do not retry automatically; read current state" if status == "UNKNOWN" else "Trusted parent unavailable"
        return {"status": status, "message": message}


def verify(arguments):
    validate_arguments("verify", arguments)
    return exchange(arguments)


def call_registry(name, arguments):
    validate_arguments(name, arguments)
    if name in WRITE_TOOLS and not writes_enabled():
        return {"status": "PERMISSION_DENIED", "message": "Registry writes disabled"}
    payload = {"operation": "ha.call_service", "request_id": secrets.token_hex(16),
               "domain": "codex_cli", "service": SERVICE_BY_TOOL[name], "data": arguments}
    return exchange(payload, mutation=name in WRITE_TOOLS)


def respond(request):
    method = request.get("method")
    if method == "initialize":
        return {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}},
                "serverInfo": {"name": "home-assistant-verification", "version": "0.1.70-haipc3"}}
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": [tool for tool in TOOLS if tool["name"] not in WRITE_TOOLS or writes_enabled()]}
    if method == "tools/call":
        try:
            params = request.get("params", {})
            if not isinstance(params, dict):
                raise Invalid("Invalid parameters")
            name, arguments = params.get("name"), params.get("arguments", {})
            if name == "verify":
                result = verify(arguments)
            elif isinstance(name, str) and name in SERVICE_BY_TOOL:
                result = call_registry(name, arguments)
            else:
                raise Invalid("Unknown tool")
        except (ValueError, TypeError, UnicodeError, RecursionError):
            result = {"status": "VALIDATION_ERROR", "message": "Invalid tool arguments"}
        return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
                "isError": result.get("status") in ERROR_STATUSES}
    raise Invalid("Unsupported method")


def main():
    if not os.environ.get("HA_VERIFICATION_CAPABILITY"):
        print("Active turn capability required", file=sys.stderr)
        return 1
    while raw := sys.stdin.buffer.readline(MAX_REQUEST + 4097):
        if len(raw) > MAX_REQUEST + 4096 or not raw.endswith(b"\n"):
            return 1
        try:
            request = strict_json(raw)
            if not isinstance(request, dict) or "id" not in request:
                continue
            response = {"jsonrpc": "2.0", "id": request["id"]}
            try:
                response["result"] = respond(request)
            except (ValueError, TypeError, AttributeError):
                response["error"] = {"code": -32601, "message": "Unsupported request"}
            print(json.dumps(response, ensure_ascii=False), flush=True)
        except (ValueError, UnicodeError, RecursionError):
            print(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Invalid JSON"}}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
