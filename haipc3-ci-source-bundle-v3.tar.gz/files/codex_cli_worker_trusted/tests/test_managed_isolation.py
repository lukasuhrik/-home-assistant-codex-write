"""Managed policy, mode rejection and readiness failure regression tests."""
import ast
import importlib.util
import json
from pathlib import Path
import subprocess
import tomllib
import unittest
from unittest.mock import patch
from test_server import server
import sandbox_isolation_probe as probe

WORKER = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("command_guard", WORKER / "command_guard.py")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


class ManagedIsolationTests(unittest.TestCase):
    def test_requirements_exact_minimum_and_no_whole_data_denial(self):
        requirements = tomllib.loads((WORKER / "requirements.toml").read_text())
        self.assertEqual(set(requirements["allowed_sandbox_modes"]), {"read-only", "workspace-write"})
        denied = requirements["permissions"]["filesystem"]["deny_read"]
        self.assertNotIn("/data", denied)
        for path in ("/run/s6", "/run/codex-bridge", "/data/options.json", "/data/worker_api_token",
                     "/data/verification.sock", "/data/codex-home/auth.json", "/data/codex-home/sessions",
                     "/data/codex-home/history.jsonl"):
            self.assertIn(path, denied)
    def test_image_has_policy_and_no_helper(self):
        docker = (WORKER / "Dockerfile").read_text()
        self.assertIn("/etc/codex/requirements.toml", docker)
        self.assertIn("chmod 0644", docker)
        self.assertIn("chown root:root", docker)
        self.assertNotIn("ha-codex-ha", docker)
        self.assertFalse((WORKER / "ha-codex-ha").exists())
    def test_cli_registers_required_mcp_and_excludes_capability(self):
        args = server.verification_mcp_args()
        pairs = args[1::2]
        self.assertIn("mcp_servers.home_assistant.required=true", pairs)
        self.assertIn("mcp_servers.home_assistant.tool_timeout_sec=240", pairs)
        exclusion = next(p for p in pairs if p.startswith("shell_environment_policy.exclude="))
        self.assertIn("HA_VERIFICATION_CAPABILITY", exclusion)
        self.assertIn("SUPERVISOR_TOKEN", exclusion)
        self.assertIn("HASSIO_TOKEN", exclusion)
        self.assertIn("HA_TOKEN", exclusion)
    def test_danger_mode_rejected_before_launch(self):
        with patch.object(server, "read_options", return_value={"codex_sandbox":"danger-full-access"}), \
             patch.object(server, "requirements_status", return_value={"ok":True,"error":""}), \
             patch.object(server, "_bubblewrap_probe") as raw, patch.object(server, "sandbox_isolation_probe") as isolation:
            self.assertFalse(server.sandbox_readiness()["ready"])
            with self.assertRaises(ValueError):
                server.build_codex_args("fixture", Path("/tmp/prompt"), Path("/tmp/result"), None)
            raw.assert_not_called()
            isolation.assert_not_called()
    def test_isolation_failure_blocks_even_working_codex(self):
        with patch.object(server, "read_options", return_value={"codex_sandbox":"workspace-write"}), \
             patch.object(server, "requirements_status", return_value={"ok":True,"error":""}), \
             patch.object(server.shutil, "which", return_value="bwrap"), \
             patch.object(server, "_bubblewrap_probe", return_value={"ok":True,"error":""}), \
             patch.object(server, "sandbox_isolation_probe", return_value={"ok":False,"error":"isolation failed"}):
            readiness = server.sandbox_readiness()
            self.assertFalse(readiness["ready"])
            self.assertIn("isolation failed", readiness["message"])
    def test_missing_requirements_runs_no_probe(self):
        with patch.object(server, "requirements_status", return_value={"ok":False,"error":"missing"}), \
             patch.object(server, "_bubblewrap_probe") as raw:
            self.assertFalse(server.sandbox_readiness()["ready"])
            raw.assert_not_called()
    def test_guard_requires_fresh_proc_and_drops_capability(self):
        args = ["--ro-bind", "/", "/", "--unshare-pid", "--proc", "/proc", "--", "/bin/true"]
        hardened = guard.guarded_args(args)
        self.assertIn("--unshare-net", hardened)
        self.assertIn(["--unsetenv", "HA_VERIFICATION_CAPABILITY"], [hardened[i:i+2] for i in range(len(hardened))])
        self.assertNotIn("--bind", hardened)
        self.assertEqual(hardened[-2:], ["--", "/bin/true"])
        with self.assertRaises(ValueError):
            guard.guarded_args(["--unshare-pid", "--", "/bin/true"])
    def test_probe_never_launches_nested_codex(self):
        tree = ast.parse((WORKER / "sandbox_isolation_probe.py").read_text())
        self.assertFalse(any(isinstance(n, ast.Import) and any(a.name == "subprocess" for a in n.names) for n in ast.walk(tree)))
    def test_unknown_readable_data_file_fails_audit(self):
        with patch.object(probe, "directory_readable", return_value=True), patch.object(probe.os, "walk", return_value=[("/data", [], ["unknown-private.json"])]), \
             patch.object(probe, "readable", return_value=True), patch.object(probe, "approved", return_value=False):
            self.assertFalse(probe.data_audit())
    def test_incomplete_inventory_fails_audit(self):
        with patch.object(probe, "directory_readable", return_value=True), patch.object(probe.os, "walk", side_effect=OSError()):
            self.assertFalse(probe.data_audit())
    def test_failed_probe_does_not_expose_stdout_or_stderr(self):
        fixture = "isolated-sensitive-fixture"
        with patch.object(server, "codex_binary_path", return_value="codex"), \
             patch.object(server.subprocess, "run", return_value=subprocess.CompletedProcess([],1,fixture,fixture)):
            result = server.sandbox_isolation_probe()
            self.assertFalse(result["ok"])
            self.assertNotIn(fixture, json.dumps(result))
