"""Registry mutation opt-in, discovery and parent authorization. No HA IO."""
import json
import os
from pathlib import Path
import secrets
import threading
import unittest
from unittest.mock import patch
import yaml
from test_server import server
import verification_mcp as mcp
from verification import Verification
from trusted_ha_bridge import Bridge

READ_TOOLS = {'verify', 'ha_area_get', 'ha_floor_get', 'ha_entity_registry_get', 'ha_device_registry_get'}
WRITE_TOOLS = {'ha_area_update', 'ha_area_set_temperature_entity'}

class Worker:
    def __init__(self, options=None):
        self.lock = threading.RLock()
        self.options = {} if options is None else options
        self.tasks = {'task': {'status':'running', 'current_turn_id':'turn'}}
    def read_options(self): return self.options
    def task_cancellation_requested(self, task): return False

class Client:
    def __init__(self): self.calls = []
    def available(self): return True
    def request(self, *args):
        self.calls.append(args)
        return {'service_response': {'status':'SUCCESS'}}

class RegistryWriteGateTests(unittest.TestCase):
    def engine(self, options=None):
        worker = Worker(options)
        engine = Verification(worker)
        engine.capabilities['task'] = 'isolated-turn-fixture'
        engine.capability_turns['task'] = 'turn'
        client = Client()
        engine.ha_bridge = Bridge(engine, client)
        return worker, engine, client
    def request(self, service='area_update'):
        data = {'area_id':'kitchen', 'name':'Kitchen'} if service == 'area_update' else {'area_id':'kitchen', 'entity_id':'sensor.room_temperature'}
        return {'operation':'ha.call_service', 'domain':'codex_cli', 'service':service, 'data':data,
                'request_id':secrets.token_hex(16), 'capability':'isolated-turn-fixture'}
    def test_default_option_and_addon_schema(self):
        config = yaml.safe_load((Path(__file__).resolve().parents[1] / 'config.yaml').read_text())
        self.assertIs(server.DEFAULT_OPTIONS['registry_write_enabled'], False)
        self.assertIs(config['options']['registry_write_enabled'], False)
        self.assertEqual(config['schema']['registry_write_enabled'], 'bool')
    def test_default_and_false_advertise_exact_reads(self):
        for value in (None, 'false', '1', 'TRUE'):
            with self.subTest(value=value), patch.dict(os.environ, {}, clear=True):
                if value is not None: os.environ['HA_REGISTRY_WRITE_ENABLED'] = value
                self.assertEqual({t['name'] for t in mcp.respond({'method':'tools/list'})['tools']}, READ_TOOLS)
    def test_true_advertises_writes(self):
        with patch.dict(os.environ, {'HA_REGISTRY_WRITE_ENABLED':'true'}, clear=True):
            self.assertEqual({t['name'] for t in mcp.respond({'method':'tools/list'})['tools']}, READ_TOOLS | WRITE_TOOLS)
    def test_parent_supplies_mcp_advertisement_setting(self):
        for options, expected in (({}, 'false'), ({'registry_write_enabled':False}, 'false'), ({'registry_write_enabled':True}, 'true'), ({'registry_write_enabled':'true'}, 'false')):
            with self.subTest(options=options), patch.object(server, 'read_options', return_value=options):
                args = server.verification_mcp_args()
                self.assertIn('mcp_servers.home_assistant.env.HA_REGISTRY_WRITE_ENABLED='+json.dumps(expected), args)
    def test_forged_mcp_write_while_disabled_has_no_ipc(self):
        with patch.dict(os.environ, {'HA_REGISTRY_WRITE_ENABLED':'false'}, clear=True), patch.object(mcp.socket, 'socket') as socket:
            for tool, service in (('ha_area_update','area_update'), ('ha_area_set_temperature_entity','area_set_temperature_entity')):
                reply = mcp.respond({'method':'tools/call','params':{'name':tool,'arguments':self.request(service)['data']}})
                self.assertTrue(reply['isError'])
                self.assertEqual(json.loads(reply['content'][0]['text'])['status'], 'PERMISSION_DENIED')
            socket.assert_not_called()
    def test_forged_parent_writes_disabled_have_zero_http_calls(self):
        for options in ({}, {'registry_write_enabled':False}, {'registry_write_enabled':'true'}, {'registry_write_enabled':1}):
            with self.subTest(options=options):
                _, engine, client = self.engine(options)
                for service in ('area_update', 'area_set_temperature_entity'):
                    self.assertEqual(engine.dispatch(self.request(service))['status'], 'PERMISSION_DENIED')
                self.assertEqual(client.calls, [])
                self.assertEqual(engine.ha_bridge.mutations, {})
    def test_mcp_advertisement_override_cannot_enable_parent_writes(self):
        _, engine, client = self.engine({'registry_write_enabled':False})
        with patch.dict(os.environ, {'HA_REGISTRY_WRITE_ENABLED':'true'}):
            self.assertEqual(engine.dispatch(self.request())['status'], 'PERMISSION_DENIED')
        self.assertEqual(client.calls, [])
    def test_direct_internal_perform_also_blocked(self):
        _, engine, client = self.engine()
        request = self.request();request.pop('capability')
        self.assertEqual(engine.ha_bridge.perform(request)['status'], 'PERMISSION_DENIED')
        self.assertEqual(client.calls, [])
    def test_true_preserves_valid_capability_authorization(self):
        for service in ('area_update', 'area_set_temperature_entity'):
            with self.subTest(service=service):
                _, engine, client = self.engine({'registry_write_enabled':True})
                self.assertEqual(engine.dispatch(self.request(service))['status'], 'SUCCESS')
                self.assertEqual(len(client.calls), 1)
    def test_true_does_not_authorize_stale_or_wrong_capability(self):
        for stale in ('capability', 'turn'):
            with self.subTest(stale=stale):
                worker, engine, client = self.engine({'registry_write_enabled':True})
                request = self.request()
                if stale == 'capability': request['capability'] = 'wrong-fixture'
                else: worker.tasks['task']['current_turn_id'] = 'new-turn'
                self.assertEqual(engine.dispatch(request)['status'], 'PERMISSION_DENIED')
                self.assertEqual(client.calls, [])
    def test_reads_remain_available_when_disabled(self):
        _, engine, client = self.engine()
        request = self.request();request['service']='area_get';request['data']={'area_id':'kitchen'}
        self.assertEqual(engine.dispatch(request)['status'], 'SUCCESS')
        self.assertEqual(len(client.calls), 1)
    def test_option_read_failure_stays_off(self):
        worker, engine, client = self.engine({'registry_write_enabled':True})
        with patch.object(worker, 'read_options', side_effect=ValueError('isolated fixture')):
            self.assertEqual(engine.dispatch(self.request())['status'], 'PERMISSION_DENIED')
        self.assertEqual(client.calls, [])
