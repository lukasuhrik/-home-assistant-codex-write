"""MCP schemas and transport failures, including post-send UNKNOWN. No HA IO."""
import io
import json
import os
import socket
import unittest
from unittest.mock import patch
import verification_mcp as mcp
from bridge_protocol import strict_json


class Connection:
    def __init__(self, reply=b'{"status":"passed"}\n', *, fail_connect=False, fail_send=False):
        self.reply = reply
        self.fail_connect, self.fail_send = fail_connect, fail_send
        self.timeouts = []
        self.sent = []
        self.closed = False
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.closed = True
    def settimeout(self, value):
        self.timeouts.append(value)
    def connect(self, path):
        self.path = path
        if self.fail_connect:
            raise OSError("isolated fixture")
    def sendall(self, raw):
        self.sent.append(raw)
        if self.fail_send:
            raise OSError("isolated fixture")
    def makefile(self, mode):
        return io.BytesIO(self.reply)


class MCPTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {"HA_VERIFICATION_CAPABILITY": "isolated-turn-fixture", "HA_REGISTRY_WRITE_ENABLED": "true"}, clear=True)
        self.env.start()
        self.addCleanup(self.env.stop)
    def call(self, name, data, connection=None):
        connection = connection or Connection()
        with patch.object(mcp.socket, "socket", return_value=connection) as constructor:
            result = mcp.respond({"method":"tools/call", "params":{"name":name,"arguments":data}})
        return json.loads(result["content"][0]["text"]), result["isError"], connection, constructor
    def test_exact_tools(self):
        tools = mcp.respond({"method":"tools/list"})["tools"]
        self.assertEqual({t["name"] for t in tools}, {"verify", "ha_area_get", "ha_floor_get",
            "ha_entity_registry_get", "ha_device_registry_get", "ha_area_update", "ha_area_set_temperature_entity"})
        for tool in tools:
            self.assertIs(tool["inputSchema"]["additionalProperties"], False)
            if tool["name"] != "verify":
                for field in ("url", "path", "shell", "domain", "service", "request_id", "capability"):
                    self.assertNotIn(field, tool["inputSchema"]["properties"])
    def test_invalid_extra_field_never_connects(self):
        body, error, _, sock = self.call("ha_area_update", {"area_id":"kitchen", "unknown":True})
        self.assertEqual(body["status"], "VALIDATION_ERROR")
        self.assertTrue(error)
        sock.assert_not_called()
    def test_invalid_types_lengths_selectors(self):
        cases = [("ha_area_get", {}), ("ha_area_get", {"area_id":"x", "area_name":"y"}),
            ("ha_floor_get", {"floor_id":False}), ("ha_area_update", {"area_id":"x", "name":"a"*256}),
            ("ha_area_update", {"area_id":"x", "aliases":[1]}),
            ("ha_entity_registry_get", {"entity_id":"not an entity"}),
            ("ha_area_set_temperature_entity", {"area_id":"x"})]
        for name, data in cases:
            with self.subTest(name=name, data_type=type(data).__name__):
                body, error, _, sock = self.call(name, data)
                self.assertEqual(body["status"], "VALIDATION_ERROR")
                self.assertTrue(error)
                sock.assert_not_called()
    def test_null_clear_is_valid(self):
        with patch.object(mcp, "exchange", return_value={"status":"NO_CHANGE"}) as exchange:
            self.call("ha_area_set_temperature_entity", {"area_id":"x", "entity_id":None})
            self.call("ha_area_update", {"area_id":"x", "floor_id":None})
            self.assertEqual(exchange.call_count, 2)
    def test_server_generates_distinct_ids_and_fixed_service(self):
        with patch.object(mcp, "exchange", return_value={"status":"SUCCESS"}) as exchange:
            for _ in range(2):
                self.call("ha_area_get", {"area_name":"Kuchyňa"})
        requests = [call.args[0] for call in exchange.call_args_list]
        self.assertNotEqual(requests[0]["request_id"], requests[1]["request_id"])
        self.assertEqual(requests[0]["service"], "area_get")
        self.assertEqual(requests[0]["domain"], "codex_cli")
    def test_listener_down_write_is_unavailable_not_unknown(self):
        body, error, connection, sock = self.call("ha_area_update", {"area_id":"x"}, Connection(fail_connect=True))
        self.assertEqual(body["status"], "UNAVAILABLE")
        self.assertTrue(error)
        sock.assert_called_once_with(socket.AF_UNIX, socket.SOCK_STREAM)
        self.assertFalse(connection.sent)
        self.assertTrue(connection.closed)
    def test_write_partial_send_unknown_and_no_retry(self):
        body, error, connection, sock = self.call("ha_area_update", {"area_id":"x"}, Connection(fail_send=True))
        self.assertEqual(body["status"], "UNKNOWN")
        self.assertTrue(error)
        self.assertEqual(len(connection.sent), 1)
        sock.assert_called_once()
    def test_response_failures_after_write_are_unknown(self):
        for raw in (b'', b'{}', b'{"status":"SUCCESS","status":"NO_CHANGE"}\n',
                    b'{"status":NaN}\n', b'\xff\n', b'x'*(256*1024)+b'\n', b'{"status":"unexpected"}\n'):
            with self.subTest(size=len(raw)):
                body, error, _, sock = self.call("ha_area_update", {"area_id":"x"}, Connection(raw))
                self.assertEqual(body["status"], "UNKNOWN")
                self.assertTrue(error)
                sock.assert_called_once()
    def test_read_response_failure_is_unavailable(self):
        body, error, _, _ = self.call("ha_area_get", {"area_id":"x"}, Connection(b''))
        self.assertEqual(body["status"], "UNAVAILABLE")
        self.assertTrue(error)
    def test_missing_capability_never_connects(self):
        with patch.dict(os.environ, {}, clear=True):
            body, error, _, sock = self.call("ha_area_get", {"area_id":"x"})
        self.assertEqual(body["status"], "PERMISSION_DENIED")
        self.assertTrue(error)
        sock.assert_not_called()
    def test_fixed_socket_override_ignored_and_timeouts(self):
        with patch.dict(os.environ, {"HA_VERIFICATION_SOCKET":"/wrong/path"}):
            body, error, connection, _ = self.call("verify", {"operation":"config_check"})
        self.assertEqual(connection.path, "/run/codex-bridge/bridge.sock")
        self.assertEqual(connection.timeouts, [2,45])
        self.assertTrue(connection.closed)
        self.assertEqual(body["status"], "passed")
        self.assertFalse(error)
    def test_request_limit_prevents_connect(self):
        with patch.object(mcp.socket, "socket") as sock:
            result = mcp.exchange({"operation":"fixture", "data":"x"*(16*1024)})
        self.assertEqual(result["status"], "VALIDATION_ERROR")
        sock.assert_not_called()
    def test_verify_regression(self):
        for data in ({"operation":"entity", "entity_id":"sensor.fixture"},
                     {"operation":"config_check"}, {"operation":"dashboard", "path":"/lovelace/0"}):
            body, error, connection, _ = self.call("verify", data)
            self.assertEqual(body["status"], "passed")
            self.assertFalse(error)
            sent = strict_json(connection.sent[0])
            self.assertEqual({k:v for k,v in sent.items() if k != "capability"}, data)
    def test_strict_parser(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}', b'\xff', b'{'):
            with self.assertRaises((ValueError, UnicodeError)):
                strict_json(raw)
    def test_all_required_error_statuses(self):
        for status in ("UNKNOWN", "UNAVAILABLE", "PERMISSION_DENIED", "VALIDATION_ERROR"):
            body, error, _, _ = self.call("ha_area_get", {"area_id":"x"}, Connection(json.dumps({"status":status}).encode()+b'\n'))
            self.assertEqual(body["status"], status)
            self.assertTrue(error)
