"""Home Assistant client contracts without a running Home Assistant instance."""
from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

API_PATH = Path(__file__).resolve().parents[2] / "custom_components" / "codex_cli" / "api.py"
SPEC = importlib.util.spec_from_file_location("codex_api_test", API_PATH)
api = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(api)


class ApiTests(unittest.IsolatedAsyncioTestCase):
    """The requests the integration's client sends to the worker and the errors it raises."""

    def setUp(self):
        """Build a client whose session returns one canned worker response."""
        self.response = MagicMock()
        self.response.status = 200
        self.response.json = AsyncMock(return_value={"ok": True})
        context = MagicMock()
        context.__aenter__ = AsyncMock(return_value=self.response)
        context.__aexit__ = AsyncMock(return_value=False)
        self.session = MagicMock()
        self.session.request.return_value = context
        self.client = api.CodexCliApiClient(self.session, "http://worker", "test-token")

    async def test_list_filters_are_encoded_and_legacy_url_stays_unchanged(self):
        """List filters go into the query string, and a call without filters requests the plain tasks URL."""
        await self.client.list_tasks()
        self.assertEqual(self.session.request.call_args.args, ("GET", "http://worker/tasks"))
        await self.client.list_tasks(limit=10, offset=20, order="updated_desc", summary=True)
        self.assertEqual(self.session.request.call_args.args, ("GET", "http://worker/tasks?limit=10&offset=20&order=updated_desc&summary=true"))

    async def test_health_is_requested_with_the_worker_token(self):
        """The health request carries the worker token, which the worker requires for it."""
        await self.client.health()
        self.assertEqual(self.session.request.call_args.args, ("GET", "http://worker/health"))
        self.assertEqual(self.session.request.call_args.kwargs["headers"], {"Authorization": "Bearer test-token"})

    async def test_continue_and_legacy_reply_use_correct_payloads(self):
        """Continue and the legacy reply each post to their own endpoint with their own field name."""
        await self.client.continue_task("chat", "More detail")
        self.assertEqual(self.session.request.call_args.args, ("POST", "http://worker/tasks/chat/continue"))
        self.assertEqual(self.session.request.call_args.kwargs["json"], {"message": "More detail"})
        await self.client.reply_task("chat", "Yes")
        self.assertEqual(self.session.request.call_args.args, ("POST", "http://worker/tasks/chat/reply"))
        self.assertEqual(self.session.request.call_args.kwargs["json"], {"reply": "Yes"})

    async def test_reply_names_its_turn_and_a_choice_goes_by_position(self):
        """A reply carries the turn id only when one is given; a picked choice is sent by position and may wait in the queue."""
        await self.client.reply_task("chat", "Yes", "turn-1")
        self.assertEqual(self.session.request.call_args.kwargs["json"], {"reply": "Yes", "turn_id": "turn-1"})
        await self.client.reply_task("chat", "Yes", None)
        self.assertEqual(self.session.request.call_args.kwargs["json"], {"reply": "Yes"})
        await self.client.reply_choice("chat", "turn-1", 2)
        self.assertEqual(self.session.request.call_args.args, ("POST", "http://worker/tasks/chat/reply"))
        self.assertEqual(self.session.request.call_args.kwargs["json"], {"choice": 2, "turn_id": "turn-1", "queue": True})

    async def test_continuation_error_is_actionable(self):
        """A refused continuation raises an error carrying the worker's own message and the HTTP status."""
        self.response.status = 409
        self.response.json.return_value = {"ok": False, "error": "The saved Codex session is unavailable."}
        with self.assertRaisesRegex(api.CodexCliApiError, "saved Codex session") as raised:
            await self.client.continue_task("chat", "More")
        self.assertEqual(raised.exception.status, 409)

    async def test_non_json_http_error_keeps_status(self):
        """An HTTP error without a JSON body still raises an error that names the status code."""
        self.response.status = 502
        self.response.json.side_effect = ValueError("not JSON")
        with self.assertRaisesRegex(api.CodexCliApiError, "HTTP 502"):
            await self.client.list_tasks()
