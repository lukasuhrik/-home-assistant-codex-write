"""Command-side checks. Only trusted parent launches Codex; this never does.

No file contents, capability values, exception strings or audit filenames leave
this process. /data files outside the explicit reviewed list fail the gate.
"""
import glob
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import urllib.error
import urllib.request

APPROVED_FILES = {"/data/codex-home/config.toml", "/data/codex-output-schema.json"}
APPROVED_TREES = ("/data/codex-home/tmp/arg0/", "/data/ha-docs/source/")
ARG0_PUBLIC_TARGETS = ("/usr/bin/", "/usr/local/bin/", "/usr/local/lib/node_modules/@openai/codex/")


def readable(path):
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
        os.close(descriptor)
        return True
    except OSError:
        return False


def directory_readable(path):
    try:
        with os.scandir(path) as entries:
            next(entries, None)
        return True
    except OSError:
        return False


def socket_accessible(path):
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(2)
            client.connect(path)
        return True
    except OSError:
        return False


def approved(path):
    # Resolve symlinks: an allowed-looking link must not expose an unrelated file.
    try:
        actual = str(Path(path).resolve(strict=True))
    except OSError:
        return False
    return (actual in APPROVED_FILES or any(actual.startswith(root) for root in APPROVED_TREES)
            or (str(path).startswith("/data/codex-home/tmp/arg0/") and any(actual.startswith(root) for root in ARG0_PUBLIC_TARGETS)))


def data_audit():
    if not directory_readable("/data"):
        return False
    count = 0
    def error(exc):
        # Permission-denied denials are expected. Other traversal errors mean
        # an incomplete inventory and must fail, rather than hide an unknown file.
        if not isinstance(exc, PermissionError):
            raise exc
    try:
        for root, dirs, files in os.walk("/data", followlinks=False, onerror=error):
            # Also examine readable symlinks to directories, without traversal.
            for name in dirs:
                path = Path(root) / name
                if path.is_symlink() and directory_readable(path) and not approved(path):
                    return False
            for name in files:
                count += 1
                if count > 100000:
                    return False
                path = os.path.join(root, name)
                if readable(path) and not approved(path):
                    return False
        return True
    except OSError:
        return False


def checks():
    result = {}
    for key, path in {
        "options_blocked": "/data/options.json",
        "worker_token_blocked": "/data/worker_api_token",
        "auth_blocked": "/data/codex-home/auth.json",
        "s6_token_blocked": "/run/s6/container_environment/SUPERVISOR_TOKEN",
    }.items():
        result[key] = not readable(path)
    result["s6_directory_blocked"] = not directory_readable("/run/s6/container_environment")
    clean_proc = True
    for path in glob.glob("/proc/[0-9]*/environ"):
        try:
            with open(path, "rb") as stream:
                # Inspect names only; never extract, print or persist values.
                names = [item.split(b"=", 1)[0] for item in stream.read(1024 * 1024).split(b"\0")]
            if any(b"SUPERVISOR" in key or b"HASSIO" in key or key in {b"HA_VERIFICATION_CAPABILITY", b"HA_TOKEN", b"OPENAI_API_KEY", b"CODEX_API_KEY"} for key in names):
                clean_proc = False
        except OSError:
            pass
    parent_namespace = int(sys.argv[1]) if len(sys.argv) == 2 else None
    result["proc_environ_blocked"] = clean_proc and parent_namespace is not None and os.stat("/proc/self/ns/pid").st_ino != parent_namespace
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        with opener.open("http://supervisor/core/api/", timeout=2):
            result["supervisor_http_blocked"] = False
    except urllib.error.HTTPError:
        result["supervisor_http_blocked"] = False
    except OSError:
        result["supervisor_http_blocked"] = True
    result["bridge_socket_blocked"] = not socket_accessible("/run/codex-bridge/bridge.sock")
    result["old_socket_blocked"] = not socket_accessible("/data/verification.sock")
    result["shell_env_clean"] = not any(
        key == "HA_VERIFICATION_CAPABILITY" or "SUPERVISOR" in key or "HASSIO" in key or key in {"HA_TOKEN", "OPENAI_API_KEY", "CODEX_API_KEY"}
        for key in os.environ)
    try:
        # All sockets are forbidden as inherited command FDs, a stronger check
        # than recognizing one pathname-less AF_UNIX descriptor.
        result["bridge_fd_absent"] = not any(os.readlink(path).startswith("socket:")
            for path in glob.glob("/proc/self/fd/[0-9]*") if os.path.lexists(path))
    except OSError:
        result["bridge_fd_absent"] = False
    result["shell_helper_absent"] = shutil.which("ha-codex-ha") is None
    result["data_audit_pass"] = data_audit()
    return result


if __name__ == "__main__":
    try:
        result = checks()
    except Exception:
        print("{}")
        sys.exit(1)
    print(json.dumps(result, sort_keys=True))
    sys.exit(0 if all(result.values()) else 1)
