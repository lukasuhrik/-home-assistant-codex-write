"""Fixed MCP schemas and bounded strict JSON shared by the two trusted peers."""
import json
import math
import re

SOCKET_PATH = "/run/codex-bridge/bridge.sock"
MAX_REQUEST = 16 * 1024
MAX_RESPONSE = 256 * 1024
CONNECT_TIMEOUT = 2
RESPONSE_TIMEOUT = 45
PARENT_LINE_TIMEOUT = 5
MUTATION_LOCK_TIMEOUT = 20


class Invalid(ValueError):
    pass


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise Invalid("Duplicate JSON field")
            result[key] = value
        return result
    def nonfinite(value):
        raise Invalid("Non-finite JSON")
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", errors="strict")
    def finite(raw):
        value = float(raw)
        if not math.isfinite(value):
            raise Invalid("Non-finite number")
        return value
    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite, parse_float=finite)
    def utf8(item):
        if isinstance(item, str):
            item.encode("utf-8", errors="strict")
        elif isinstance(item, dict):
            for key, child in item.items():
                utf8(key)
                utf8(child)
        elif isinstance(item, list):
            for child in item:
                utf8(child)
    utf8(value)
    return value


def string(nullable=False, minimum=1, pattern=None):
    schema = {"type": ["string", "null"] if nullable else "string",
              "minLength": minimum, "maxLength": 255}
    if pattern:
        schema["pattern"] = pattern
    return schema


def schema(properties, required=(), selectors=()):
    result = {"type": "object", "additionalProperties": False,
              "properties": properties, "required": list(required)}
    if selectors:
        result["oneOf"] = [{"required": [key]} for key in selectors]
    return result


AREA_SELECTORS = {"area_id": string(), "area_name": string()}
FLOOR_SELECTORS = {"floor_id": string(), "floor_name": string()}
ENTITY = string(pattern=r"^[a-z0-9_]+\.[a-z0-9_]+$")
REGISTRY_SCHEMAS = {
    "ha_area_get": schema(AREA_SELECTORS, selectors=AREA_SELECTORS),
    "ha_floor_get": schema(FLOOR_SELECTORS, selectors=FLOOR_SELECTORS),
    "ha_entity_registry_get": schema({"entity_id": ENTITY}, ["entity_id"]),
    "ha_device_registry_get": schema({"device_id": string()}, ["device_id"]),
    "ha_area_update": schema({**AREA_SELECTORS, "name": string(),
        "floor_id": string(nullable=True), "icon": string(nullable=True),
        "aliases": {"type": "array", "maxItems": 100, "items": string()}},
        selectors=AREA_SELECTORS),
    "ha_area_set_temperature_entity": schema({**AREA_SELECTORS,
        "entity_id": {**ENTITY, "type": ["string", "null"]}}, ["entity_id"], AREA_SELECTORS),
}
SERVICE_BY_TOOL = {
    "ha_area_get": "area_get", "ha_floor_get": "floor_get",
    "ha_entity_registry_get": "entity_registry_get",
    "ha_device_registry_get": "device_registry_get",
    "ha_area_update": "area_update",
    "ha_area_set_temperature_entity": "area_set_temperature_entity",
}
WRITE_TOOLS = {"ha_area_update", "ha_area_set_temperature_entity"}
VERIFY_SCHEMA = schema({
    "operation": {"type": "string", "enum": ["entity", "config_check", "logs", "dashboard", "dashboard_readback"]},
    "entity_id": ENTITY, "expected_state": string(minimum=0),
    "attributes": {"type": "array", "maxItems": 10, "items": string()},
    "path": string(minimum=0, pattern=r"^(?:/[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)?/?)?$"),
    "save_pending": {"type": "boolean"},
}, ["operation"])


def validate_value(value, spec):
    allowed = spec["type"]
    if not isinstance(allowed, list):
        allowed = [allowed]
    if value is None and "null" in allowed:
        return
    if "string" in allowed and isinstance(value, str):
        value.encode("utf-8", errors="strict")
        if not spec.get("minLength", 0) <= len(value) <= spec.get("maxLength", 255):
            raise Invalid("String length")
        if spec.get("minLength", 0) and not value.strip():
            raise Invalid("Blank string")
        if "enum" in spec and value not in spec["enum"]:
            raise Invalid("Invalid enum")
        if "pattern" in spec and not re.fullmatch(spec["pattern"], value):
            raise Invalid("Invalid string")
        return
    if "boolean" in allowed and type(value) is bool:
        return
    if "array" in allowed and isinstance(value, list) and len(value) <= spec["maxItems"]:
        for item in value:
            validate_value(item, spec["items"])
        return
    raise Invalid("Invalid field type")


def validate_arguments(tool, arguments):
    spec = VERIFY_SCHEMA if tool == "verify" else REGISTRY_SCHEMAS.get(tool)
    if spec is None or not isinstance(arguments, dict):
        raise Invalid("Unsupported tool arguments")
    if set(arguments) - set(spec["properties"]) or not set(spec["required"]) <= set(arguments):
        raise Invalid("Invalid fields")
    choices = spec.get("oneOf", [])
    if choices and sum(set(choice["required"]) <= set(arguments) for choice in choices) != 1:
        raise Invalid("Exactly one selector required")
    for key, value in arguments.items():
        validate_value(value, spec["properties"][key])
    if tool == "verify" and arguments["operation"] == "entity" and "entity_id" not in arguments:
        raise Invalid("Entity ID required")
