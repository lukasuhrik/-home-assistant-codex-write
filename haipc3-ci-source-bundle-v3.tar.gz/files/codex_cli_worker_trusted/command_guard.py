"""Require fresh proc/network namespaces; never expose IPC to commands."""
import os
import sys

REAL_BWRAP = "/opt/codex-sandbox/bwrap.real"


def guarded_args(args):
    if args == ["--help"]:
        return ["--cap-drop", "ALL", "--help"]
    if "--" not in args:
        raise ValueError("Missing command separator")
    split = args.index("--")
    options, command = args[:split], args[split + 1:]
    if not command or "--unshare-pid" not in options:
        raise ValueError("Fresh PID namespace required")
    if not any(options[i:i+2] == ["--proc", "/proc"] for i in range(len(options))):
        raise ValueError("Inherited proc forbidden")
    extra = ["--unshare-net", "--cap-drop", "ALL"]
    for name in ("HA_VERIFICATION_CAPABILITY", "SUPERVISOR_TOKEN", "HASSIO_TOKEN", "HA_TOKEN", "OPENAI_API_KEY", "CODEX_API_KEY"):
        extra.extend(["--unsetenv", name])
    return [*options, *extra, "--", *command]


if __name__ == "__main__":
    try:
        args = guarded_args(sys.argv[1:])
        os.execv(REAL_BWRAP, [REAL_BWRAP, *args])
    except (OSError, ValueError):
        print("Command isolation unavailable; refusing execution", file=sys.stderr)
        sys.exit(1)
