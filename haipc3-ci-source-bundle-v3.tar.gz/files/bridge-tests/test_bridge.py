"""Trusted-parent/IPC tests; no HA network or production service calls."""
import contextlib
import importlib.machinery
import importlib.util
import io
import json
import os
from pathlib import Path
import secrets
import socket
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1] / 'codex_cli_worker_trusted'
sys.path.insert(0,str(ROOT))
import trusted_ha_bridge as bridge
import verification
class Worker:
    def __init__(self):
        self.lock=threading.RLock()
        self.tasks={'task':{'status':'running','current_turn_id':'turn'}}
        self.cancel=False
        self.options={'registry_write_enabled':True}  # Explicit opt-in for existing mutation tests.
    def read_options(self):return self.options
    def task_cancellation_requested(self,task):return self.cancel


class Client:
    def __init__(self):self.calls=[];self.response={};self.fail=False;self.token=True
    def available(self):return self.token
    def request(self,*args):
        self.calls.append(args)
        if self.fail:raise bridge.Unavailable('not emitted')
        return self.response


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.worker=Worker();self.engine=verification.Verification(self.worker)
        self.cap='isolated-capability-fixture';self.engine.capabilities['task']=self.cap;self.engine.capability_turns['task']='turn'
        self.client=Client();self.engine.ha_bridge=bridge.Bridge(self.engine,self.client)
        self.logs=io.StringIO()
        self.log_patch=patch.object(bridge.LOG,'handlers',[__import__('logging').StreamHandler(self.logs)])
        self.log_patch.start();self.addCleanup(self.log_patch.stop)
    def request(self,op='ha.ping',**kwargs):return {'operation':op,'request_id':secrets.token_hex(16),**kwargs}
    def dispatch(self,r):return self.engine.dispatch({**r,'capability':self.cap})
    def call(self,domain='codex_cli',service='area_get',data=None):
        return self.request('ha.call_service',domain=domain,service=service,data={'area_id':'kitchen'} if data is None else data)
    def test_ping(self):
        self.assertEqual(self.dispatch(self.request())['status'],'SUCCESS');self.assertEqual(self.client.calls,[('GET','/core/api/')])
    def test_config_projection(self):
        self.client.response={'version':'2026.9.4','secret':'not forwarded'}
        self.assertEqual(self.dispatch(self.request('ha.config'))['result'],{'version':'2026.9.4'})
    def test_services(self):
        self.client.response=[{'domain':'codex_cli','services':{k:{} for k in bridge.SERVICES}}]
        self.assertTrue(self.dispatch(self.request('ha.services'))['all_allowed_visible'])
    def test_missing_services(self):
        self.client.response=[];self.assertEqual(len(self.dispatch(self.request('ha.services'))['missing_registry_services']),6)
    def test_allowed_service(self):
        self.client.response={'service_response':{'status':'NO_CHANGE','verified':True}}
        self.assertEqual(self.dispatch(self.call())['status'],'NO_CHANGE')
        self.assertEqual(self.client.calls[0],('POST','/core/api/services/codex_cli/area_get?return_response',{'area_id':'kitchen'}))
    def test_wrong_domain(self):
        self.assertEqual(self.dispatch(self.call(domain='homeassistant'))['status'],'PERMISSION_DENIED');self.assertFalse(self.client.calls)
    def test_unknown_service(self):self.assertEqual(self.dispatch(self.call(service='delete'))['status'],'PERMISSION_DENIED')
    def test_arbitrary_url(self):self.assertEqual(self.dispatch(self.request(url='http://untrusted'))['status'],'PERMISSION_DENIED')
    def test_method_injection(self):self.assertEqual(self.dispatch(self.request(method='POST'))['status'],'PERMISSION_DENIED')
    def test_arbitrary_path(self):self.assertEqual(self.dispatch(self.request(path='/core/restart'))['status'],'PERMISSION_DENIED')
    def test_unknown_operation(self):self.assertEqual(self.dispatch(self.request('ha.shell'))['status'],'PERMISSION_DENIED')
    def test_forbidden_entity_field(self):self.assertEqual(self.dispatch(self.call(service='entity_registry_update',data={'entity_id':'sensor.x','platform':'bad'}))['status'],'PERMISSION_DENIED')
    def test_forbidden_device_field(self):self.assertEqual(self.dispatch(self.call(service='device_registry_update',data={'device_id':'x','identifiers':[]}))['status'],'PERMISSION_DENIED')
    def test_targets_missing(self):self.assertEqual(self.dispatch(self.call(data={}))['status'],'PERMISSION_DENIED')
    def test_targets_ambiguous(self):self.assertEqual(self.dispatch(self.call(data={'area_id':'x','area_name':'x'}))['status'],'PERMISSION_DENIED')
    def test_bad_id(self):self.assertEqual(self.dispatch({'operation':'ha.ping','request_id':'bad'})['status'],'PERMISSION_DENIED')
    def test_removed_operations_denied(self):
        for service in ("floor_create", "floor_update", "area_create", "entity_registry_update", "device_registry_update"):
            self.assertEqual(self.dispatch(self.call(service=service))["status"], "PERMISSION_DENIED")
        self.assertEqual(self.dispatch(self.request("ha.restart_core"))["status"], "PERMISSION_DENIED")
        self.assertFalse(self.client.calls)
        with self.assertRaises(bridge.Invalid):
            self.engine.ha_bridge.perform(self.request("ha.restart_core"))

    def test_unknown_no_retry(self):
        self.client.fail=True;r=self.call(service="area_update");self.assertEqual(self.dispatch(r)['status'],'UNKNOWN')
        self.assertEqual(self.dispatch(r)['status'],'UNKNOWN');self.assertEqual(len(self.client.calls),1)

    def test_reused_id_different_request(self):
        self.client.response={'service_response':{'status':'SUCCESS'}};r=self.call(service="area_update");self.dispatch(r)
        self.assertEqual(self.dispatch({**self.call(service='area_update',data={'area_id':'kitchen','name':'Changed request'}),'request_id':r['request_id']})['status'],'PERMISSION_DENIED')

    def test_no_parent_token(self):self.client.token=False;self.assertEqual(self.dispatch(self.request())['status'],'UNAVAILABLE');self.assertFalse(self.client.calls)
    def test_expired_capability(self):
        self.engine.capabilities.clear()
        self.assertEqual(self.dispatch(self.request())['status'],'PERMISSION_DENIED')
    def test_cancelled(self):
        self.worker.cancel=True
        self.assertEqual(self.dispatch(self.request())['status'],'PERMISSION_DENIED')
    def test_wrong_capability(self):
        self.assertEqual(self.engine.dispatch({**self.request(),'capability':'wrong'})['status'],'PERMISSION_DENIED')
    def test_read_verification_dispatch_preserved(self):
        with patch.object(self.engine,'run',return_value={'status':'legacy'}) as run:
            self.assertEqual(self.engine.dispatch({'operation':'entity','entity_id':'sensor.x','capability':self.cap}),{'status':'legacy'})
            run.assert_called_once()
    def test_no_auth_header_in_logs(self):
        self.dispatch(self.request());self.assertNotIn('Authorization',self.logs.getvalue());self.assertNotIn(self.cap,self.logs.getvalue())
    def test_mutation_ledger_bounded(self):
        self.engine.ha_bridge.mutations={str(i):None for i in range(1024)}
        self.assertEqual(self.dispatch(self.call(service="area_update"))['status'],'UNAVAILABLE');self.assertFalse(self.client.calls)

    def test_concurrent_service_once(self):
        self.client.response={'service_response':{'status':'SUCCESS'}};r=self.call(service="area_update");threads=[threading.Thread(target=self.dispatch,args=(r,)) for _ in range(10)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertEqual(len(self.client.calls),1)

    def test_changed_turn_denied_before_http(self):
        self.worker.tasks['task']['current_turn_id']='next-turn'
        self.assertEqual(self.dispatch(self.call())['status'],'PERMISSION_DENIED')
        self.assertFalse(self.client.calls)
    def test_mutation_lock_timeout_no_http(self):
        with patch.object(self.engine.ha_bridge,'lock') as lock:
            lock.acquire.return_value=False
            self.assertEqual(self.dispatch(self.call(service='area_update'))['status'],'UNAVAILABLE')
            lock.acquire.assert_called_once_with(timeout=20)
            lock.release.assert_not_called()
        self.assertFalse(self.client.calls)
    def test_read_failure_is_unavailable(self):
        self.client.fail=True
        self.assertEqual(self.dispatch(self.call())['status'],'UNAVAILABLE')
    def test_mutation_cancelled_after_http_is_unknown(self):
        def response(*args):
            self.client.calls.append(args);self.worker.cancel=True
            return {'service_response':{'status':'SUCCESS'}}
        self.client.request=response
        self.assertEqual(self.dispatch(self.call(service='area_update'))['status'],'UNKNOWN')
        self.assertEqual(len(self.client.calls),1)
    def test_strict_json(self):
        for raw in ('{', '{"a":1,"a":2}', '{"v":NaN}'):
            with self.assertRaises(ValueError):bridge.strict_json(raw)


class ParentCredentials(unittest.TestCase):
    def test_parent_token_available(self):
        with patch.dict(os.environ,{'SUPERVISOR_TOKEN':'isolated-parent-fixture'}):self.assertTrue(bridge.SupervisorClient().available())
    def test_parent_without_token(self):
        with patch.dict(os.environ,{},clear=True):self.assertFalse(bridge.SupervisorClient().available())
    def test_parent_token_absent_from_failure_audit(self):
        fixture='isolated-parent-token-fixture'
        worker=Worker();engine=verification.Verification(worker)
        engine.capabilities['task']='cap-fixture';engine.capability_turns['task']='turn'
        opener=types.SimpleNamespace(open=lambda *a,**kw: (_ for _ in ()).throw(OSError(fixture)))
        request={'operation':'ha.call_service','domain':'codex_cli','service':'area_update','data':{'area_id':'kitchen'},'request_id':secrets.token_hex(16),'capability':'cap-fixture'}
        with patch.dict(os.environ,{'SUPERVISOR_TOKEN':fixture}),patch.object(bridge.urllib.request,'build_opener',return_value=opener),self.assertLogs(bridge.LOG,level='INFO') as logs:
            result=engine.dispatch(request)
        self.assertEqual(result['status'],'UNKNOWN')
        self.assertNotIn(fixture,json.dumps(result));self.assertNotIn(fixture,str(logs.output));self.assertNotIn('Authorization',str(logs.output))
    def test_codex_env_sanitized_even_with_legacy_option(self):
        import server
        with patch.dict(os.environ,{'SUPERVISOR_TOKEN':'isolated-parent-fixture','HASSIO_TOKEN':'isolated-parent-fixture','HA_TOKEN':'fixture'},clear=True),patch.object(server,'read_options',return_value={'HA_TOKEN':'legacy-option-fixture'}):
            result=server.codex_env()
            for name in ('SUPERVISOR_TOKEN','HASSIO_TOKEN','HA_TOKEN','HA_URL'):self.assertNotIn(name,result)
    def test_http_headers_internal_and_timeout(self):
        response=types.SimpleNamespace(status=200,read=lambda n:b'{"message":"isolated-parent-fixture","password":"fixture"}')
        cm=contextlib.nullcontext(response);seen=[]
        def open_(req,timeout):seen.append((req,timeout));return cm
        opener=types.SimpleNamespace(open=open_)
        with patch.dict(os.environ,{'SUPERVISOR_TOKEN':'isolated-parent-fixture'}),patch.object(bridge.urllib.request,'build_opener',return_value=opener):
            result=bridge.SupervisorClient().request('GET','/core/api/')
            self.assertEqual(seen[0][0].full_url,'http://supervisor/core/api/');self.assertEqual(seen[0][1],15)
            self.assertNotIn('isolated-parent-fixture',json.dumps(result));self.assertEqual(result['password'],'[REDACTED]')
    def test_redirect_denied(self):
        with self.assertRaises(bridge.Unavailable):bridge.NoRedirect().redirect_request(None,None,302,'',{},'http://bad')
