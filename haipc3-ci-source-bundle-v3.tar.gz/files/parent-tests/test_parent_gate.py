"""Required real gates, ONLY in a disposable trusted-parent test environment.

No skip decorators. Missing external context fails instead of reporting success.
Fixture environment stages the candidate managed policy, wrapper and root paths;
never run this suite against a live worker or within a Codex command sandbox.
"""
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1] / "codex_cli_worker_trusted"
sys.path.insert(0, str(ROOT))
import server as worker
import verification
import verification_mcp as mcp
from bridge_protocol import SOCKET_PATH


class ParentGate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if os.environ.get("HAIPC3_DISPOSABLE_PARENT_TEST") != "1" or "HA_VERIFICATION_CAPABILITY" in os.environ:
            raise RuntimeError("EXTERNAL_PARENT_TEST_REQUIRED; no nested Codex probes permitted")
        if not worker.requirements_status()["ok"]:
            raise RuntimeError("Candidate managed policy is not staged")
        for path in ("/data/options.json", "/data/worker_api_token", "/data/codex-home/auth.json",
                     "/run/s6/container_environment/SUPERVISOR_TOKEN"):
            # Parent fixture paths must exist and be readable; absence cannot
            # falsely satisfy a shell denial test. Never consume file values.
            fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
            os.close(fd)
        if not Path(SOCKET_PATH).is_socket():
            raise RuntimeError("Disposable parent listener fixture must already be running")
        cls.isolation = worker.sandbox_isolation_probe()
        if not cls.isolation["ok"]:
            raise RuntimeError("ISOLATION_FAILED; functional tests prohibited")

    def setUp(self):
        self.fixture = types.SimpleNamespace(lock=threading.RLock(),
            tasks={"task":{"status":"running","current_turn_id":"turn"}},
            task_cancellation_requested=lambda task: False)
        self.engine = verification.Verification(self.fixture)
        self.cap = "isolated-capability-fixture"
        self.engine.capabilities["task"] = self.cap
        self.engine.capability_turns["task"] = "turn"
        self.calls = []
        def request(*args):
            self.calls.append(args)
            return {"service_response":{"status":"SUCCESS", "after":{"area_id":"fixture", "name":"Fixture"}}}
        self.engine.ha_bridge.client = types.SimpleNamespace(available=lambda:True, request=request)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "bridge.sock"
        self.listener = self.engine.serve(self.path)
        self.addCleanup(self.listener.server_close)
        self.addCleanup(self.listener.shutdown)

    def test_native_isolation_and_audit_pass(self):
        self.assertTrue(self.isolation["ok"])
        self.assertTrue(self.isolation["checks"]["data_audit_pass"])

    def test_real_mcp_area_read(self):
        with patch.object(mcp, "SOCKET_PATH", str(self.path)), \
             patch.dict(os.environ, {"HA_VERIFICATION_CAPABILITY":self.cap}):
            result = mcp.call_registry("ha_area_get", {"area_id":"fixture"})
        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(result["result"]["after"]["area_id"], "fixture")
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.path.parent.stat().st_mode & 0o777, 0o700)

    def test_real_stale_capability_denied_no_http(self):
        self.fixture.tasks["task"]["current_turn_id"] = "later"
        with patch.object(mcp, "SOCKET_PATH", str(self.path)), \
             patch.dict(os.environ, {"HA_VERIFICATION_CAPABILITY":self.cap}):
            result = mcp.call_registry("ha_area_get", {"area_id":"fixture"})
        self.assertEqual(result["status"], "PERMISSION_DENIED")
        self.assertFalse(self.calls)

    def test_real_invalid_framing_and_json_denied(self):
        for raw in (b'x'*16385+b'\n', b'{"capability":"a","capability":"b"}\n',
                    b'{"v":NaN}\n', b'\xff\n'):
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(10)
                client.connect(str(self.path))
                client.sendall(raw)
                with client.makefile("rb") as stream:
                    result = json.loads(stream.readline())
                self.assertEqual(result["status"], "PERMISSION_DENIED")
        self.assertFalse(self.calls)

    def test_fifth_connection_unavailable(self):
        held = []
        try:
            entered = threading.Event()
            lock = threading.Lock()
            count = [0]
            original = self.listener.finish_request
            def finish(request, address):
                with lock:
                    count[0] += 1
                    if count[0] == 4:
                        entered.set()
                return original(request, address)
            self.listener.finish_request = finish
            for _ in range(4):
                client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                client.connect(str(self.path))
                held.append(client)
            self.assertTrue(entered.wait(2), "Four connections must be accepted first")
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as fifth:
                fifth.settimeout(2)
                fifth.connect(str(self.path))
                result = json.loads(fifth.recv(4096))
            self.assertEqual(result["status"], "UNAVAILABLE")
        finally:
            for client in held:
                client.close()
        self.assertFalse(self.calls)
