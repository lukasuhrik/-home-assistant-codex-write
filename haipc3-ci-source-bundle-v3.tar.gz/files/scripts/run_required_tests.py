"""Fail closed: no skipped/security-unavailable lane counts as ALL PASS."""
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT / "codex_cli_worker_trusted"
ENV = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
UNIT_RUN = """
import sys, unittest
suite = unittest.defaultTestLoader.discover(sys.argv[1])
result = unittest.TextTestRunner(verbosity=1).run(suite)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
"""

PYTEST_RUN = """
import pytest, sys
class Gate:
    skipped = False
    def pytest_runtest_logreport(self, report):
        if report.skipped:
            self.skipped = True
    def pytest_collectreport(self, report):
        if report.skipped:
            self.skipped = True
gate = Gate()
code = pytest.main(sys.argv[1:], plugins=[gate])
raise SystemExit(0 if code == 0 and not gate.skipped else 1)
"""


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, env=ENV, capture_output=True, text=True)
    # Emit only status/test names; no raw assertion bodies, file data or logs.
    for line in result.stderr.splitlines():
        if line.startswith(("ERROR:", "FAIL:", "Ran ", "FAILED", "OK", "SKIPPED")) or "ModuleNotFoundError:" in line:
            print(line)
    if result.returncode:
        print("REQUIRED_GATE_FAILED — no commit/build/publish/install")
        raise SystemExit(1)


if __name__ == "__main__":
    run([sys.executable, "scripts/validate_candidate.py"], ROOT)
    run([sys.executable, "-c", UNIT_RUN, "registry-tests"], ROOT)
    run([sys.executable, "-c", UNIT_RUN, "bridge-tests"], ROOT)
    run([sys.executable, "-c", UNIT_RUN, "tests"], WORKER)
    run([sys.executable, "-c", UNIT_RUN, "parent-tests"], ROOT)
    run([sys.executable, "tests/codex_verification_smoke.py"], WORKER)
    run([sys.executable, "-c", PYTEST_RUN, "tests/verification_socket_test.py", "tests/ha", "-r", "s"], WORKER)
    print("ALL REQUIRED TESTS PASS")
