"""CI-only gate: never substitutes for live HAOS isolation."""
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ENV = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
TESTS = [
    "test_verification.VerificationTests.test_shared_browser_pages_are_not_charged_twice",
    "test_verification.VerificationTests.test_tracks_and_stops_detached_browser_descendants",
]
UNIT = """
import sys, unittest
loader = unittest.defaultTestLoader
suite = loader.discover(sys.argv[2]) if sys.argv[1] == 'discover' else loader.loadTestsFromNames(sys.argv[2:])
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
"""
PYTEST = """
import sys, pytest
class Gate:
    skipped = False
    def pytest_runtest_logreport(self, report):
        if report.skipped: self.skipped = True
    def pytest_collectreport(self, report):
        if report.skipped: self.skipped = True
gate = Gate()
result = pytest.main(sys.argv[1:], plugins=[gate])
raise SystemExit(0 if result == 0 and not gate.skipped else 1)
"""

def run(args, cwd, extra=None):
    subprocess.run(args, cwd=cwd, env={**ENV, **(extra or {})}, check=True)

def worker_units(worker, args):
    run([sys.executable, '-c', UNIT, *args], worker, {'PYTHONPATH': str(worker / 'tests')})

def repeats(worker, label):
    for names in ([TESTS[0]], [TESTS[1]], TESTS):
        for number in range(1, 21):
            print(f'{label}: {names}: {number}/20', flush=True)
            worker_units(worker, ['names', *names])

if __name__ == '__main__':
    own = os.getpid()
    proc = int(Path('/proc/self/stat').read_text().split()[0])
    assert own == proc, 'PID namespace /proc mismatch'
    assert Path(f'/proc/{own}/stat').exists()
    repeats(Path(os.environ['HAIPC2_BASELINE_DIR']) / 'codex_cli_worker_trusted', 'HAIPC2')
    worker = ROOT / 'codex_cli_worker_trusted'
    repeats(worker, 'HAIPC3')
    worker_units(worker, ['discover', 'tests'])
    run([sys.executable, '-c', UNIT, 'discover', 'registry-tests'], ROOT)
    run([sys.executable, '-c', UNIT, 'discover', 'bridge-tests'], ROOT)
    run([sys.executable, 'scripts/validate_candidate.py'], ROOT)
    run([sys.executable, '-c', PYTEST, 'tests/verification_socket_test.py'], worker)
    ha_python = Path(os.environ['HAIPC3_HA_TEST_PYTHON'])
    assert ha_python.is_absolute() and ha_python.is_file()
    run([str(ha_python), '-c', PYTEST, 'tests/ha', '-o', 'asyncio_mode=auto'], worker)
    print('CI TEST GATE PASS; LIVE HAOS ISOLATION TEST REQUIRED: YES')
